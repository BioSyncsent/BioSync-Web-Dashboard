import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";
// Optional:
// import { getAnalytics } from "firebase/analytics";



const firebaseConfig = {
  apiKey: "AIzaSyCqoyl-GM58YQM4xWSicl1q5oWfMEqgFJA",
  authDomain: "fyp-attendance-51ba3.firebaseapp.com",
  projectId: "fyp-attendance-51ba3",
  storageBucket: "fyp-attendance-51ba3.firebasestorage.app",
  messagingSenderId: "73352570242",
  appId: "1:73352570242:web:53c8e0ae2606b30fbadb9b",
};

const app = initializeApp(firebaseConfig);

// Export Firebase services
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);

// Only enable analytics if you really need it
// export const analytics = getAnalytics(app);

export default app;